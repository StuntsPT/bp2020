### Ex1

moths_data = read.csv("/home/francisco/Syncthing/general/Classes/FCUL/Bioinformatica_pratica/2018/bp2018/docs/exam_data/moths.tsv", sep="\t", header=TRUE, row.names=2)

# a)
for (target_fun in c(mean, median, sd, var)) {
    print(apply(moths_data[,-1], 2, target_fun))
}

# b)
png(filename="/home/francisco/boxplot_sp_richness.png", width=600, height=500)
boxplot(Sp.Richness ~ Location, data=moths_data, col=2:8, xlab="Regions",
        ylab="Sp. Richness", main="Sp. Richness per region boxplot")
dev.off()

png(filename="/home/francisco/boxplot_captures.png", width=600, height=500)
boxplot(Captures ~ Location, data=moths_data, col=2:8, xlab="Regions",
        ylab="Captures", main="Captures per region boxplot")
dev.off()

# c)

# Prova "A"
road_NO2 = moths_data[moths_data[,"Location"] == "Region_A" |
                      moths_data[,"Location"] == "Region_B" |
                      moths_data[,"Location"] == "Region_D",
                      "NO2" ]
no_road_NO2 = moths_data[moths_data[,"Location"] == "Region_C" |
                         moths_data[,"Location"] == "Region_E" |
                         moths_data[,"Location"] == "Region_F" |
                         moths_data[,"Location"] == "Region_G",
                         "NO2" ]

shapiro.test(x=road_NO2)
shapiro.test(x=no_road_NO2)
wilcox.test(x=road_NO2, y=no_road_NO2, conf.level=0.95)

# Prova "B"
road_PM10 = moths_data[moths_data[,"Location"] == "Region_A" |
                       moths_data[,"Location"] == "Region_B" |
                       moths_data[,"Location"] == "Region_D",
                       "PM10" ]
no_road_PM10 = moths_data[moths_data[,"Location"] == "Region_C" |
                          moths_data[,"Location"] == "Region_E" |
                          moths_data[,"Location"] == "Region_F" |
                          moths_data[,"Location"] == "Region_G",
                          "PM10" ]

shapiro.test(x=road_PM10)
shapiro.test(x=no_road_PM10)
t.test(x=road_PM10, y=no_road_PM10, conf.level=0.95)

# d)
generic_correlation = function(x_data, y_data, x_label, y_label, title, file_name, alpha) {
  if (shapiro.test(x_data)$p.value < alpha |
      shapiro.test(y_data)$p.value < alpha) {
    cor_method = "spearman"
  } else {
    cor_method = "pearson"
  }
  significance = cor.test(x=x_data, y=y_data, method=cor_method)$p.value
  model = lm(y_data ~ x_data)
  strength = summary(model)$r.squared

  png(filename=file_name, width=600, height=500)
  plot(x=x_data, y=y_data,
       ylim=range(y_data)*c(0.8,1.20),
       xlim=range(x_data)*c(0.8,1.10),
       xlab=x_label,
       ylab=y_label,
       main=title,
       pch="o",
       col="3")
  abline(model, lwd=3, col="navy")
  dev.off()

  return(c(significance, strength))
}

# e)

# Prova "A"
GC = generic_correlation(x_data=moths_data$PM10,
                         y_data=moths_data$Sp.Richness,
                         x_label="[PM10] (µg/m³)",
                         y_label="Species Richness",
                         title="Species Richness Vs. [PM10]",
                         file_name="/home/francisco/ex_1_scatter_A.png",
                         alpha=0.05)
print(GC)

# Prova "B"
GC = generic_correlation(x_data=moths_data$NO2,
                         y_data=moths_data$Sp.Richness,
                         x_label="[NO2] (µg/m³)",
                         y_label="Species Richness",
                         title="Species Richness Vs. [PM10]",
                         file_name="/home/francisco/ex_1_scatter_B.png",
                         alpha=0.05)
print(GC)

# f)
# Prova "A"
GC = generic_correlation(x_data=moths_data$PM10,
                         y_data=moths_data$Captures,
                         x_label="[PM10] (µg/m³)",
                         y_label="Number of captured individuals",
                         title="Captured individuals Vs. [PM10]",
                         file_name="/home/francisco/ex_1_scatter_A2.png",
                         alpha=0.05)
print(GC)

# Prova "B"
GC = generic_correlation(x_data=moths_data$NO2,
                         y_data=moths_data$Captures,
                         x_label="[NO2] (µg/m³)",
                         y_label="Species Richness",
                         title="Captured individuals Vs. [NO2]",
                         file_name="/home/francisco/ex_1_scatter_B2.png",
                         alpha=0.05)
print(GC)


### Ex. 2
greenhouse_data_A = read.csv("/home/francisco/Syncthing/general/Classes/FCUL/Bioinformatica_pratica/2018/bp2018/docs/exam_data/greenhouses.csv", header=TRUE, sep=",", row.names=1)
greenhouse_data_B = read.csv("/home/francisco/Syncthing/general/Classes/FCUL/Bioinformatica_pratica/2018/bp2018/docs/exam_data/GreenHouses.csv", header=TRUE, sep=",", row.names=1)

# a)
# Prova "A"
write.csv(table(greenhouse_data_A), file="/home/francisco/greenhouse_tableA.csv")

# Prova "B"
write.csv(table(greenhouse_data_B), file="/home/francisco/greenhouse_tableB.csv")

# b)
# Prova "A"
png(filename="/home/francisco/barplot_greenhouseA.png", width=700, height=500)
barplot(t(table(greenhouse_data_A)),
        beside=TRUE,
        col=c("forestgreen","orange"),
        ylim=c(0, max(table(greenhouse_data_A)*1.20)),
        xlab="Filter type",
        ylab="Frequency",
        main="Frequency of healty and infected individuals by filter type")

legend("topright", c("Healty", "Infected"),
       col=c("forestgreen", "orange"), pch=15)
dev.off()

# Prova "B"
png(filename="/home/francisco/barplot_greenhouseB.png", width=700, height=500)
barplot(t(table(greenhouse_data_B)),
        beside=TRUE,
        col=c("forestgreen","orange"),
        ylim=c(0, max(table(greenhouse_data_B)*1.20)),
        xlab="Filter type",
        ylab="Frequency",
        main="Frequency of healty and infected individuals by filter type")

legend("topright", c("Healty", "Infected"),
       col=c("forestgreen", "orange"), pch=15)
dev.off()

# c)
# Prova "A"
fisher.test(table(greenhouse_data_A))

# Prova "B"
chisq.test(table(greenhouse_data_B))

# d)
# Text only

### Ex. 3
cicadas_data = read.csv("https://raw.githubusercontent.com/StuntsPT/BP2017/master/classes/exame_2/Cicadas.csv", header=TRUE, sep=",")

# a)
print(table(cicadas_data$Species))

# b)
just_morph_data = cicadas_data[,3:length(cicadas_data)]

source("https://bioconductor.org/biocLite.R")
biocLite("pcaMethods")
library(pcaMethods)

color_categories = cicadas_data$Group

morph_pca <- pca(just_morph_data, scale="uv", center=TRUE, nPcs=2, method="nipals")

png(filename="~/PCA_cicadas.png")
slplot(morph_pca,
       scol=color_categories,
       scoresLoadings=c(T,F),
       main="PCA from Cicadas morphological data")
legend("bottomright",
       legend=c("Tettigettalna aneabi", "Tettigettalna helienthemi"),
       col=unique(color_categories),
       pch=1)
dev.off()

# c)
# N/A

# d)
png(filename="~/PCA_loadings_cicadas.png")
slplot(morph_pca,
       scol=color_categories,
       scoresLoadings=c(F,T),
       main="PCA from Cicadas morphological data")
dev.off()
